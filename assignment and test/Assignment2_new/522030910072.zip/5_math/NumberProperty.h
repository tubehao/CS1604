#ifndef NUMBERPROPERTY_H_INCLUDED
#define NUMBERPROPERTY_H_INCLUDED
bool prime(int x);

bool perfect(int n);
#endif // NUMBERPROPERTY_H_INCLUDED
