#ifndef SQRT_H_INCLUDED
#define SQRT_H_INCLUDED

float MySqrt(float g,float x);

#endif // SQRT_H_INCLUDED
