#ifndef MYMATH_H_INCLUDED
#define MYMATH_H_INCLUDED

#include "Convert2Int.h"
#include "NumberProperty.h"
#include "Sqrt.h"

#endif // MYMATH_H_INCLUDED
