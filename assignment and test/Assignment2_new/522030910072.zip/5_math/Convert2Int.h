#ifndef CONVERT2INT_H_INCLUDED
#define CONVERT2INT_H_INCLUDED
int Turncate(float x);
int Round(float x);
int LargerAbs(float x);
#endif // CONVERT2INT_H_INCLUDED
